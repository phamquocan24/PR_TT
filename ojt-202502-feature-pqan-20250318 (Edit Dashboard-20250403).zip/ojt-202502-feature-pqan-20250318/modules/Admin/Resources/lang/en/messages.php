<?php

return [
    'resource_created' => ':resource created',
    'resource_updated' => ':resource updated',
    'resource_deleted' => ':resource deleted',
    'permission_denied' => 'Permission Denied (required permission: ":permission")',
];
