<?php

use Illuminate\Support\Facades\Route;
use Modules\Category\Http\Controllers\Admin\CategoryController;
use Modules\Category\Http\Controllers\Admin\CategoryTreeController;


Route::group(['prefix' => 'categories'], function () {
    Route::group(['prefix' => 'tree'], function () {
        Route::get('/', [CategoryTreeController::class, 'index'])->name('admin.categories.tree.index');
        Route::put('/', [CategoryTreeController::class, 'update'])->name('admin.categories.tree.update');
    });

    Route::get('/', [CategoryController::class, 'index'])->name('admin.categories.index');
    Route::post('/', [CategoryController::class, 'store'])->name('admin.categories.store');
    Route::get('{id}', [CategoryController::class, 'show'])->name('admin.categories.show');
    Route::put('{id}', [CategoryController::class, 'update'])->name('admin.categories.update');
    Route::delete('{id}', [CategoryController::class, 'destroy'])->name('admin.categories.destroy');
});

