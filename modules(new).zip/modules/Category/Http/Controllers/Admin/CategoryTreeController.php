<?php

namespace Modules\Category\Http\Controllers\Admin;

use Modules\Category\Entities\Category;
use Modules\Category\Http\Responses\CategoryTreeResponse;

class CategoryTreeController
{
    protected $model;

    public function __construct(Category $category)
    {
        $this->model = $category;
    }

    public function index()
    {
        $categories = Category::withoutGlobalScope('active')->orderByRaw('-position DESC')->get();
        return new CategoryTreeResponse($categories);
    }

    public function update()
    {

    }
}
