<?php

namespace Modules\Category\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Modules\Category\Entities\Category;
use Modules\Category\Http\Request\CategoryRequest;

class CategoryController
{
    protected $model;

    protected string $label = 'category::categories.category';

    protected string $viewPath = 'category::admin.categories';

    public function __construct(Category $category)
    {
        $this->model = $category;
    }

    public function index()
    {
        return view("{$this->viewPath}.index");
    }

    public function create()
    {
        return view("{$this->viewPath}.create");
    }

    public function store(CategoryRequest $request)
    {
        try {
            $this->model->create(
                $this->getRequest('store')->except(array_keys($request->query()))
            );
            return redirect()->route("admin.categories.index")
                ->withSuccess(trans('admin::messages.resource_created', ['resource' => trans($this->label)]));
        } catch (\Exception $e) {
            report($e);
            return redirect()->route('admin.categories.index')->with('error', 'Đã xảy ra lỗi khi thêm dữ liệu. Vui lòng thử lại!');
        }
    }

    public function show($id)
    {
        return $this->model->withoutGlobalScope('active')->find($id);
    }

    public function edit($id)
    {
        $category = $this->model->withoutGlobalScope('active')->findOrFail($id);
        return view("{$this->viewPath}.edit", compact('category'));
    }

    public function update($id)
    {
        try {
            $category = $this->model->withoutGlobalScope('active')->findOrFail($id);
            $category->update(
                $this->getRequest('update')->except(array_keys(request()->query()))
            );

            return redirect()->route("admin.categories.index")
                ->withSuccess(trans('admin::messages.resource_updated', ['resource' => trans($this->label)]));
        } catch (\Exception $e) {
            report($e);
            return redirect()->route('admin.categories.index')->with('error', 'Đã xảy ra lỗi khi thêm dữ liệu. Vui lòng thử lại!');
        }
    }

    public function destroy(string $ids)
    {
        $this->model->withoutGlobalScope('active')->findOrFail($ids)->delete();
        return back()->withSuccess(trans('admin::messages.resource_deleted', ['resource' => trans($this->label)]));
    }

    protected function getRequest(string $action): Request
    {
        return request();
    }
}
