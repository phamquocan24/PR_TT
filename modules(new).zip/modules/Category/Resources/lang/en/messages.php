<?php

return [
    'category_order_updated' => 'Category order updated',
];
