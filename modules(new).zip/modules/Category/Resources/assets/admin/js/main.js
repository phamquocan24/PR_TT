import CategoryForm from "./CategoryForm";

new CategoryForm();
