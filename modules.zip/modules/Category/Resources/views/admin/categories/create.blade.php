@extends('admin::layout')

@component('admin::components.page.header')
    @slot('title', trans('category::categories.categories'))

    <li><a href="{{ route('admin.categories.index') }}">{{ trans('category::categories.categories') }}</a></li>
    <li class="active">{{ trans('category::categories.create') }}</li>
@endcomponent

@section('content')
    <form method="POST" action="{{ route('admin.categories.store') }}" class="form-horizontal" id="category-form" novalidate>
        @csrf

        <div class="box">
            <div class="box-body">
                <div class="row">
                    <div class="col-md-2">
                        <!-- Nút Add Root Category sẽ chuyển hướng về trang index -->
                        <a href="{{ route('admin.categories.index') }}" class="btn btn-default">Add Root Category</a></br>

                        <!-- Nút Add Subcategory sẽ hiển thị form nhập dữ liệu cho danh mục con -->
                        <button class="btn btn-default" type="button" style="margin-top: 10px" id="addSubCategoryBtn">Add Subcategory</button>

                        <div class="m-b-10" style="margin-top: 20px">
                            <a href="#" class="collapse-all">Collapse All</a> |
                            <a href="#" class="expand-all">Expand All</a>
                        </div>

                        <!-- Hiển thị cây danh mục -->
                        <div id="category-tree" class="form-group">
                            @foreach ($categoriesTree as $categoryItem)
                                @include('category::admin.categories.partials.category_item', ['category' => $categoryItem])
                            @endforeach
                        </div>
                    </div>

                    <div class="col-md-10">
                        <div class="tab-pane fade in active" id="general">
                            <h3 class="tab-content-title">{{ trans('category::categories.general') }}</h3>

                            <div class="form-group">
                                <label for="name" class="col-md-3 control-label">{{ trans('category::categories.form.name') }}<span class="m-l-5 text-red">*</span></label>
                                <div class="col-md-9">
                                    <input name="name" class="form-control" id="name" type="text" value="{{ old('name') }}">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="is_searchable" class="col-md-3 control-label">{{ trans('category::categories.form.searchable') }}</label>
                                <div class="col-md-9">
                                    <div class="checkbox">
                                        <input type="hidden" value="0" name="is_searchable">
                                        <input type="checkbox" name="is_searchable" id="is_searchable" value="1">
                                        <label for="is_searchable">{{ trans('category::categories.form.show_in_search') }}</label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="is_active" class="col-md-3 control-label">{{ trans('category::categories.form.status') }}</label>
                                <div class="col-md-9">
                                    <div class="checkbox">
                                        <input type="hidden" value="0" name="is_active">
                                        <input type="checkbox" name="is_active" id="is_active" value="1">
                                        <label for="is_active">{{ trans('category::categories.form.enable') }}</label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-10 col-md-offset-2">
                                <button type="submit" class="btn btn-primary" data-loading>
                                    {{ trans('admin::resource.save') }}
                                </button>

                                <button type="button" class="btn btn-link text-red btn-delete p-l-0" data-toggle="modal" data-target="#deleteModal">
                                    Delete
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <!-- Form để thêm danh mục con -->
    <div id="addSubcategoryFormContainer" style="display: none;">
        <form method="POST" action="{{ route('admin.categories.store') }}" class="form-horizontal" novalidate>
            @csrf

            <div class="box">
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-12">
                            <h3 class="tab-content-title">Add Subcategory</h3>

                            <div class="form-group">
                                <label for="sub_name" class="col-md-3 control-label">Subcategory Name</label>
                                <div class="col-md-9">
                                    <input name="name" class="form-control" id="sub_name" type="text" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="parent_id" class="col-md-3 control-label">Parent Category</label>
                                <div class="col-md-9">
                                    <input type="hidden" name="parent_id" value="{{ old('parent_id', $category->id) }}">
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-10 col-md-offset-2">
                                    <button type="submit" class="btn btn-primary">Save Subcategory</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <!-- Modal Xác Nhận Xóa -->
    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Confirm Delete</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete this category?
                </div>
                <div class="modal-footer">
                    <form method="POST" action="{{ route('admin.categories.destroy', $category->id) }}">
                        @csrf
                        @method('DELETE')
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

@endsection

@component('admin::components.page.index_table')
    @slot('buttons', ['create'])
    @slot('resource', 'categories')
    @slot('name', trans('category::categories.categories'))
@endcomponent

@push('scripts')
    <script type="module">
        document.querySelector('.collapse-all').addEventListener('click', function(e) {
            e.preventDefault();
            const items = document.querySelectorAll('.category-item');
            items.forEach(item => {
                const childrenList = item.querySelector('.children');
                if (childrenList) {
                    childrenList.style.display = 'none';
                    item.classList.add('collapsed');
                }
            });
        });

        document.querySelector('.expand-all').addEventListener('click', function(e) {
            e.preventDefault();
            const items = document.querySelectorAll('.category-item');
            items.forEach(item => {
                const childrenList = item.querySelector('.children');
                if (childrenList) {
                    childrenList.style.display = 'block';
                    item.classList.remove('collapsed');
                }
            });
        });

        // Xử lý khi nhấn nút "Add Subcategory"
        document.getElementById("addSubCategoryBtn").addEventListener("click", function() {
            // Hiển thị form thêm danh mục con
            document.getElementById("addSubcategoryFormContainer").style.display = "block";
        });
    </script>
@endpush
