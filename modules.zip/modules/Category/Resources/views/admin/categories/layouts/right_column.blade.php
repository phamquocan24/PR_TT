<div class="box" v-for="(section, index) in formRightSections" :data-id="section" :key="index">
    @include('brand::admin.brands.layouts.sections.media')
</div>
