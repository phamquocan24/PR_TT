<?php

namespace Modules\Category\Http\Controllers\Admin;

use App\Models\Category; // Đảm bảo đã import đúng loại Category
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Foundation\Application;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Modules\Admin\Traits\HasCrudActions;
use Modules\Category\Entities\Category as EntitiesCategory; // Lưu ý là sử dụng EntitiesCategory
use Carbon\Carbon;
use Modules\Category\Http\Request\CategoryRequest;

class CategoryController
{
    protected string $label = 'category::categories.category';
    protected string $viewPath = 'category::admin.categories';

    /**
     * Show a list of categories with tree structure.
     *
     * @return Response
     */
    public function index()
    {
        $categories = EntitiesCategory::all();
        $categoriesTree = $this->buildCategoryTree($categories); // Tạo cây danh mục
    
        return view('category::admin.categories.index', compact('categoriesTree'));
    }

    /**
     * Build category tree structure recursively.
     *
     * @param $categories
     * @param null $parentId
     * @return mixed
     */
    private function buildCategoryTree($categories, $parentId = null)
    {
        // Lọc các danh mục con có parent_id tương ứng
        $branch = $categories->filter(function ($category) use ($parentId) {
            return $category->parent_id == $parentId;
        });

        // Với mỗi danh mục con, đệ quy tìm các danh mục con của nó
        foreach ($branch as $category) {
            $category->children = $this->buildCategoryTree($categories, $category->id); // Recursively build children
        }

        return $branch;
    }

    /**
     * Show the form for creating a new category.
     *
     * @return Response
     */
    public function create()
    {
        // Lấy tất cả các danh mục và tổ chức thành cấu trúc cây
        $categories = EntitiesCategory::all();
        $categoriesTree = $this->buildCategoryTree($categories);
    
        // Trả về view tạo mới danh mục với dữ liệu cây danh mục
        return view("{$this->viewPath}.create", compact('categoriesTree'));
    }
    
    /**
     * Store a newly created category in storage.
     *
     * @param CategoryRequest $request
     * @return Response
     */
    public function store(CategoryRequest $request)
    {
        try {
            // Tạo mới danh mục
            $category = new EntitiesCategory();
            
            // Lấy dữ liệu từ request và điền vào đối tượng Category
            $category->fill($request->validated());
            
            // Nếu là danh mục con, set parent_id
            if ($request->has('parent_id') && $request->parent_id) {
                $category->parent_id = $request->parent_id;
            }
    
            // Kiểm tra và thiết lập trạng thái kích hoạt cho danh mục
            $category->is_active = $request->has('is_active') && $request->is_active == 1 ? 1 : 0;
    
            // Lưu danh mục vào cơ sở dữ liệu
            $category->save();
    
            // Quay lại trang danh sách danh mục với thông báo thành công
            return redirect()->route('admin.categories.index')->with('success', 'Dữ liệu đã được thêm thành công!');
        } catch (\Exception $e) {
            report($e);
            return redirect()->route('admin.categories.index')->with('error', 'Đã xảy ra lỗi khi thêm dữ liệu. Vui lòng thử lại!');
        }
    }    
    /**
     * Show the form for editing the specified category.
     *
     * @param int $id
     * @return Factory|View|Application
     */
    public function edit($id)
{
    // Lấy danh mục cần chỉnh sửa
    $category = EntitiesCategory::findOrFail($id);

    // Lấy tất cả danh mục để hiển thị cây danh mục
    $categories = EntitiesCategory::all();
    $categoriesTree = $this->buildCategoryTree($categories); // Get categories tree structure

    // Trả về view chỉnh sửa danh mục với dữ liệu
    return view("{$this->viewPath}.edit", compact('category', 'categoriesTree'));
}
    /**
     * Update the specified category in storage.
     *
     * @param CategoryRequest $request
     * @param int $id
     * @return Response
     */
    public function update(CategoryRequest $request, $id)
    {
        try {
            // Tìm danh mục theo ID
            $category = EntitiesCategory::findOrFail($id);
            $category->fill($request->validated());
            $category->is_active = $request->has('is_active') && $request->is_active == 1 ? 1 : 0;
            $category->save();

            // Quay lại trang danh sách với thông báo thành công
            return redirect()->route('admin.categories.index')->with('success', 'Dữ liệu đã được cập nhật thành công!');
        } catch (\Exception $e) {
            report($e);
            return redirect()->route('admin.categories.index')->with('error', 'Có lỗi xảy ra khi cập nhật dữ liệu. Vui lòng thử lại!');
        }
    }

    /**
     * Delete the specified category in storage.
     *
     * @param int $id
     * @return Response
     */
    public function destroy($id)
    {
        try {
            // Tìm danh mục theo ID
            $category = EntitiesCategory::findOrFail($id);
            
            // Xóa danh mục
            $category->delete();

            // Quay lại trang danh sách với thông báo thành công
            return redirect()->route('admin.categories.index')->with('success', 'Danh mục đã được xóa thành công!');
        } catch (\Exception $e) {
            report($e);
            return redirect()->route('admin.categories.index')->with('error', 'Đã có lỗi xảy ra khi xóa danh mục!');
        }
    }
}
