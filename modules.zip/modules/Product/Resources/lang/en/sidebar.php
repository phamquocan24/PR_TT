<?php

return [
    'products' => 'Products',
    'create_product' => 'Create Product',
    'all_products' => 'All Products',
];
