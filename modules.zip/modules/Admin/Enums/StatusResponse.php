<?php

namespace Modules\Admin\Enums;

final class StatusResponse
{
    const SUCCESS = 'success';
    const FAILURE = 'failure';
}
