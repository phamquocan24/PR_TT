import _ from "lodash";
import Sortable from "sortablejs";

window._ = _;
window.Sortable = Sortable;
