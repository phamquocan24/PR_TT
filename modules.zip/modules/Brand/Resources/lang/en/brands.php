<?php
return [
    'brands' => 'Brands',
    'name' => 'Name',
    'logo' => 'Logo',
    'general' => 'General',
    'form' => [
        'name' => 'Name',
        'status' => 'Status',
        'enable' => 'Enable the brand',

    ],
];

